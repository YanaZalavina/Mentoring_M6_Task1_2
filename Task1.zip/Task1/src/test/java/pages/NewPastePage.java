package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class NewPastePage extends AbstractPage{

    private static final String HOMEPAGE_URL = "https://pastebin.com/";
    private String startPartOfPathForVariantOfPasteExpirations = "//span[@class='select2-results']//li[text()='";
    private String startPartOfPathForVariantOfSyntaxHighlighting = "//*[@aria-label='------ POPULAR LANGUAGES -------']//li[text()='";
    private String endPartOfPath = "']";

    public NewPastePage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//*[contains(@class, 'content__title')][contains(text(), 'New Paste')]")
    private WebElement titleNameField;
    @FindBy(xpath="//textarea[@id='postform-text']")
    private WebElement newPasteField;
    @FindBy(xpath = "//*[@class='form-group field-postform-expiration']//*[@class = 'select2-selection__arrow']")
    private WebElement pasteExpirationDropdownButton;
    @FindBy(xpath = "//input[@id='postform-name']")
    private WebElement nameTitleField;
    @FindBy(xpath = "//button[@class='btn -big']")
    private WebElement createNewPasteButton;
    @FindBy(xpath = "//*[@class='form-group field-postform-format']//*[@class = 'select2-selection__arrow']")
    private WebElement syntaxHighlightingDropdownButton;

    public NewPastePage openPage() {
        driver.get(HOMEPAGE_URL);
        new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(titleNameField));
        return this;
    }

    public NewPastePage enterTextForNewPaste(String textForNewPaste){
        newPasteField.click();
        newPasteField.sendKeys(textForNewPaste);
        return this;
    }

    private String createXPath(String valueOfText, String startPartOfPath, String endPartOfPath){
        return startPartOfPath
                +valueOfText
                +endPartOfPath;
    }

    public NewPastePage selectPasteExpiration(String valueOfPasteExpiration){
        pasteExpirationDropdownButton.click();
        WebElement variantOfPasteExpirations = driver.findElement(By.xpath(createXPath(valueOfPasteExpiration, startPartOfPathForVariantOfPasteExpirations, endPartOfPath)));
        variantOfPasteExpirations.click();
        return this;
    }

    public NewPastePage enterNameTitle(String nameTitle){
        nameTitleField.click();
        nameTitleField.sendKeys(nameTitle);
        return this;
    }

    public NewPastePage clickOnCreateNewPasteButton(){
        createNewPasteButton.click();
        return this;
    }

    public NewPastePage selectSyntaxHighlighting(String valueOfSyntaxHighlighting){
        syntaxHighlightingDropdownButton.click();
        WebElement variantOfPasteExpirations = driver.findElement(By.xpath(createXPath(valueOfSyntaxHighlighting, startPartOfPathForVariantOfSyntaxHighlighting, endPartOfPath)));
        variantOfPasteExpirations.click();
        return this;
    }

}
