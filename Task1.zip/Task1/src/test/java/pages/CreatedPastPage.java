package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CreatedPastPage extends AbstractPage{
    private String endPartOfPath = "']";
    private String startPartNameTitleOfCreatedPaste = "//h1[text()='";
    private String startPartSelectedSyntax = "//a[text()='";

    public CreatedPastPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(titleOfCreatedPasteField));
    }

    @FindBy(xpath = "//div[@class='details']")
    private WebElement titleOfCreatedPasteField;
    @FindBy(xpath = "//textarea")
    private WebElement pasteField;

    private String createXPath(String valueOfText, String startPartOfPath, String endPartOfPath){
        return startPartOfPath
                +valueOfText
                +endPartOfPath;
    }

    public Boolean getElementWithNameTitle(String nameTitleOfCreatedPaste){
        WebElement elementWithNameTitle = driver.findElement(By.xpath(createXPath(nameTitleOfCreatedPaste, startPartNameTitleOfCreatedPaste, endPartOfPath)));
        return elementWithNameTitle.isDisplayed();
    }

    public Boolean getElementWithSelectedSyntax(String nameSelectedSyntax){
        WebElement elementWithSelectedSyntax = driver.findElement(By.xpath(createXPath(nameSelectedSyntax, startPartSelectedSyntax, endPartOfPath)));
        return elementWithSelectedSyntax.isDisplayed();
    }

    public String getTextOfPaste(){
        return pasteField.getText();
    }
}
