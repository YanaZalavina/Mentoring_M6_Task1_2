package tests;

import org.testng.Assert;
import org.testng.annotations.*;
import pages.CreatedPastPage;
import pages.NewPastePage;

public class CreatePasteWithSyntaxTest extends ConfigTests{

    @Test
    public void checkCreatedPastTest_Syntax() {
        new NewPastePage(driver)
                .openPage()
                .enterTextForNewPaste("git config --global user.name  \"New Sheriff in Town\" " +
                        "%n git reset $(git commit-tree HEAD^{tree} -m \"Legacy code\") " +
                        "%n git push origin master --force")
                .selectSyntaxHighlighting("Bash")
                .selectPasteExpiration("10 Minutes")
                .enterNameTitle("how to gain dominance among developers")
                .clickOnCreateNewPasteButton();
        Assert.assertTrue(new CreatedPastPage(driver).getElementWithSelectedSyntax("Bash"));
    }
    @Test
    public void checkCreatedPastTest_TextPaste(){
        new NewPastePage(driver)
                .openPage()
                .enterTextForNewPaste("git config --global user.name  \"New Sheriff in Town\" " +
                        "%n git reset $(git commit-tree HEAD^{tree} -m \"Legacy code\") " +
                        "%n git push origin master --force")
                .selectSyntaxHighlighting("Bash")
                .selectPasteExpiration("10 Minutes")
                .enterNameTitle("how to gain dominance among developers")
                .clickOnCreateNewPasteButton();
        Assert.assertTrue(new CreatedPastPage(driver).getTextOfPaste().equals("git config --global user.name  \"New Sheriff in Town\" " +
                "%n git reset $(git commit-tree HEAD^{tree} -m \"Legacy code\") " +
                "%n git push origin master --force"));
    }

}
