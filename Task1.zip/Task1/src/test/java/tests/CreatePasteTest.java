package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.CreatedPastPage;
import pages.NewPastePage;

public class CreatePasteTest extends ConfigTests{

    @Test
    public void createNewPasteTest() {
        new NewPastePage(driver)
                .openPage()
                .enterTextForNewPaste("Hello from WebDriver")
                .selectPasteExpiration("10 Minutes")
                .enterNameTitle("helloweb")
                .clickOnCreateNewPasteButton();
        Assert.assertTrue(new CreatedPastPage(driver).getElementWithNameTitle("helloweb"));
    }

}
