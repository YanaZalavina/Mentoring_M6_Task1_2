package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;

public class ConfigTests {
    protected WebDriver driver;
    @BeforeClass(alwaysRun = true)
    public void browserSetUp(){
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }
    @AfterClass(alwaysRun = true)
    public void browserQuit(){
        driver.quit();
        driver = null;
    }
}
